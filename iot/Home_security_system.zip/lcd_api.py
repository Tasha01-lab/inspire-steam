# lcd_api.py
import time

class LcdApi:
    LCD_CLR = 0x01
    LCD_HOME = 0x02
    LCD_ENTRY_MODE = 0x04
    LCD_DISPLAY_CTRL = 0x08
    LCD_FUNCTION_SET = 0x20

    ENTRY_LEFT = 0x02
    DISPLAY_ON = 0x04
    FUNCTION_2LINES = 0x08

    def __init__(self, num_lines, num_columns):
        self.num_lines = num_lines
        self.num_columns = num_columns
        self.cursor_x = 0
        self.cursor_y = 0

    def clear(self):
        self.hal_write_command(self.LCD_CLR)
        time.sleep_ms(2)

    def home(self):
        self.hal_write_command(self.LCD_HOME)
        time.sleep_ms(2)

    def move_to(self, col, row):
        self.cursor_x = col
        self.cursor_y = row
        addr = col + (0x40 * row)
        self.hal_write_command(0x80 | addr)

    def putstr(self, string):
        for char in string:
            self.hal_write_data(ord(char))